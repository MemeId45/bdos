
#ifndef _OS_H_
#define _OS_H_

#include <sys/types.h>

#include "../../kernel/core/api/kernel/syscall.h"
#include "../../kernel/core/api/kernel/syscall_table.h"

#endif 
