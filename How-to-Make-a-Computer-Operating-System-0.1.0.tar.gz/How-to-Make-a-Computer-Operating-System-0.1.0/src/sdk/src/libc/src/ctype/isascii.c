
 

#include <ctype.h>

int isascii( int c ) {
    return ( ( unsigned int )c < 128u );
}
