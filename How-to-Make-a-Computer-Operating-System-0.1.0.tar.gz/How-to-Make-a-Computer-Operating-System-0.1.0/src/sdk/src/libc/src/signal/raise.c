
 

#include <signal.h>



int raise( int signal ) {
    printf( "raise(): Not yet implemented!\n" );

    return -1;
}
