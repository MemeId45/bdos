#include <unistd.h>

pid_t getppid( void ) {
    /* TODO! */

    return 0;
}
