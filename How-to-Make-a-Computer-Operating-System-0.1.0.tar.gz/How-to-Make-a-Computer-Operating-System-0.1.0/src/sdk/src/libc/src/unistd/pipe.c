#include <unistd.h>


int pipe( int pipefd[2] ) {
    /* TODO */

    printf( "TODO: pipe() not yet implemented!\n" );

    return -1;
}
