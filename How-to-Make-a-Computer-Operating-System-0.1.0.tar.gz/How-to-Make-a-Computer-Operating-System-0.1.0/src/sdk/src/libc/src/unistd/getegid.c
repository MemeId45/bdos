#include <unistd.h>

gid_t getegid( void ) {
    return 0;
}
