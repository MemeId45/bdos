#include <unistd.h>


unsigned int alarm( unsigned int seconds ) {
    /* TODO */

    printf( "TODO: alarm() not yet implemented!\n" );

    return 0;
}
