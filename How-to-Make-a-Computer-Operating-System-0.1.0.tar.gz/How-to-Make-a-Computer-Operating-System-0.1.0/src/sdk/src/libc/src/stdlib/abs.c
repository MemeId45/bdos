
 

#include <stdlib.h>

int abs( int j ) {
    if ( j < 0 ) {
        return -j;
    } else {
        return j;
    }
}
