
 

#include <stdlib.h>

double atof( const char* s ) {
    return strtod( s, ( char** )NULL );
}
