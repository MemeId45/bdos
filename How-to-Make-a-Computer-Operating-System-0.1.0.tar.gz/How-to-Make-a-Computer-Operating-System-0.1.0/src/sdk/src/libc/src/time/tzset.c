
 

void tzset( void ) {
}
